package skeleton;

public class Flare extends FlareGun {
    /**
     *A Flare nev�nek ki�r�s��rt felel�s f�ggv�ny
     */
    @Override
    public void namestate(){
        System.out.print("flare");
    }
}
