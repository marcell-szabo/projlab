package skeleton;

public class Gun extends FlareGun{
    /**
     *A Gun nev�nek ki�r�s��rt felel�s f�ggv�ny
     */
    @Override
    public void namestate(){
        System.out.print("gun");
    }
}
