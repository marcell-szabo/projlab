package skeleton;

public class Charge extends FlareGun {
    /**
     *A Charge nev�nek ki�r�s��rt felel�s f�ggv�ny
     */
    @Override
    public void namestate(){
        System.out.print("charge");
    }
}
