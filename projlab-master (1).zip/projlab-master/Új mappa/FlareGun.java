
import java.util.*;

/**
 * A jelzőpisztoly alkotóelemeinek felvételével foglalkozó osztály.
 */
public class FlareGun extends Item {

    /**
     * Default constructor
     */
    public FlareGun() {
    }


    /**
	* Attribútumként átadva önmaga referenciáját meghívja a Player osztály addPart(FlareGun) függvényét.
     * @param p Player
     * @return Result
     */
    public Result pickMeUp(Player p) {
        // TODO implement here
        return null;
    }

}