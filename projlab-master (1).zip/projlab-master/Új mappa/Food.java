
import java.util.*;

/**
 * Étel felvételének kezelésére szolgáló osztály.
 */
public class Food extends Item {

    /**
     * Default constructor
     */
    public Food() {
    }

    /**
	* Meghívja a Player osztály increaseHeat() függvényét. Amivel az általa hívott metódus tér vissza, az lesz ennek a függvénynek is a visszatérési értéke.
     * @param p Player
     * @return Result
     */
    public Result pickMeUp(Player p) {
        // TODO implement here
        return null;
    }

}