package skeleton;

public class Main {

    public static void main(String[] args) {
        Skeleton skel = new Skeleton();
        skel.runSkeleton();
    }
}
