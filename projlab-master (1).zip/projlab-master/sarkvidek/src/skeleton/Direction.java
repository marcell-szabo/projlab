package skeleton;

import java.util.*;

/**
 * Enumeration oszt�ly, amely a n�gy ir�ny k�z�l vehet fel egy �rt�ket.
 */
public enum Direction {
    UP, RIGHT, DOWN, LEFT;
}