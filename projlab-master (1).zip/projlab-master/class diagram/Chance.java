
import java.util.*;

/**
 * 
 */
public class Chance {

    /**
     * Default constructor
     */
    public Chance() {
    }

    /**
     * 
     */
    public void STAY;

    /**
     * 
     */
    public void FALL;

    /**
     * 
     */
    public void DROWN;

}