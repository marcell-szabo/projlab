
import java.util.*;

/**
 * 
 */
public class Igloo {

    /**
     * Default constructor
     */
    public Igloo() {
    }

}