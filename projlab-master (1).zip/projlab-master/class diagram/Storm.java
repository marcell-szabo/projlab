
import java.util.*;

/**
 * 
 */
public class Storm {

    /**
     * Default constructor
     */
    public Storm() {
    }



    /**
     * 
     */
    public void storm() {
        // TODO implement here
    }

}