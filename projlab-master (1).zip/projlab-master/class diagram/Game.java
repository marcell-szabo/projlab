
import java.util.*;

/**
 * 
 */
public class Game {

    /**
     * Default constructor
     */
    public Game() {
    }

    /**
     * 
     */
    private Player players;






    /**
     * 
     */
    private FlareGun flare_gun;

    /**
     * 
     */
    public void init() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setActualFields() {
        // TODO implement here
    }

    /**
     * 
     */
    public void mainLoop() {
        // TODO implement here
    }

    /**
     * @return
     */
    public int getPlayerNumber() {
        // TODO implement here
        return 0;
    }

    /**
     * @param r
     */
    public void endGame(Result r) {
        // TODO implement here
    }

    /**
     * @param f
     */
    public void addPart(FlareGun f) {
        // TODO implement here
    }

    /**
     * @return
     */
    public boolean haveAllParts() {
        // TODO implement here
        return false;
    }

}