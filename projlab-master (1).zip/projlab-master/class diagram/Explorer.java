
import java.util.*;

/**
 * 
 */
public class Explorer extends Player {

    /**
     * Default constructor
     */
    public Explorer() {
    }

    /**
     * 
     */
    private static void heatlimit = 4;

    /**
     * 
     */
    public void specialSkill() {
        // TODO implement here
    }

    /**
     * @return
     */
    public abstract Result specialSkill();

}