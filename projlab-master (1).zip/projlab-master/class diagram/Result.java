
import java.util.*;

/**
 * 
 */
public class Result {

    /**
     * Default constructor
     */
    public Result() {
    }

    /**
     * 
     */
    public void OK;

    /**
     * 
     */
    public void WIN;

    /**
     * 
     */
    public void DIE;

    /**
     * 
     */
    public void NOTHING;

}