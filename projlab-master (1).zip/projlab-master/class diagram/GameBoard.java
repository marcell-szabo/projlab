
import java.util.*;

/**
 * 
 */
public class GameBoard {

    /**
     * Default constructor
     */
    public GameBoard() {
    }




    /**
     * @param allplayer
     */
    public void init(int allplayer) {
        // TODO implement here
    }

    /**
     * 
     */
    public void setNeighbours() {
        // TODO implement here
    }

    /**
     * @return
     */
    public Field getStartField() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Result storm() {
        // TODO implement here
        return null;
    }

}