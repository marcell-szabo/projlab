
import java.util.*;

/**
 * 
 */
public class Snow {

    /**
     * Default constructor
     */
    public Snow() {
    }

    /**
     * 
     */
    private int layers;

}