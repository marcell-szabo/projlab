
import java.util.*;

/**
 * 
 */
public class Food extends Item {

    /**
     * Default constructor
     */
    public Food() {
    }

    /**
     * @param p 
     * @return
     */
    public Result pickMeUp(Player p) {
        // TODO implement here
        return null;
    }

    /**
     * @param p 
     * @return
     */
    public abstract Result pickMeUp(Player p);

}