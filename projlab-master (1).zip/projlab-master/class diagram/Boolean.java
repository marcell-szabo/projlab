
import java.util.*;

/**
 * 
 */
public class Boolean {

    /**
     * Default constructor
     */
    public Boolean() {
    }

}