
import java.util.*;

/**
 * 
 */
public class Flare extends Item {

    /**
     * Default constructor
     */
    public Flare() {
    }

    /**
     * @param p 
     * @return
     */
    public abstract Result pickMeUp(Player p);

}