
import java.util.*;

/**
 * 
 */
public class Direction {

    /**
     * Default constructor
     */
    public Direction() {
    }

    /**
     * 
     */
    public void UP;

    /**
     * 
     */
    public void RIGHT;

    /**
     * 
     */
    public void DOWN;

    /**
     * 
     */
    public void LEFT;

}