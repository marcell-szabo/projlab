
import java.util.*;

/**
 * 
 */
public abstract class Item {

    /**
     * Default constructor
     */
    public Item() {
    }


    /**
     * @param p 
     * @return
     */
    public abstract Result pickMeUp(Player p);

}