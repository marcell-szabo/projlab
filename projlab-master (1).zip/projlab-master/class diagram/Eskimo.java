
import java.util.*;

/**
 * 
 */
public class Eskimo extends Player {

    /**
     * Default constructor
     */
    public Eskimo() {
    }

    /**
     * 
     */
    private static void heatlimit = 5;

    /**
     * 
     */
    public void specialSkill() {
        // TODO implement here
    }

    /**
     * @return
     */
    public abstract Result specialSkill();

}