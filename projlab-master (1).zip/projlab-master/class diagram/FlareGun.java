
import java.util.*;

/**
 * 
 */
public class FlareGun extends Item {

    /**
     * Default constructor
     */
    public FlareGun() {
    }


    /**
     * @param p 
     * @return
     */
    public Result pickMeUp(Player p) {
        // TODO implement here
        return null;
    }

    /**
     * @param p 
     * @return
     */
    public abstract Result pickMeUp(Player p);

}